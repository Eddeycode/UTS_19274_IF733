import { Admin } from './admin.model';

export interface GPU extends Admin{

}