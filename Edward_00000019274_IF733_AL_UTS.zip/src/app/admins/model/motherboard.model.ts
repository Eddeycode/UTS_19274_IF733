import { Admin } from './admin.model';

export interface MOBO extends Admin {
    chipset:string;
    proMerk: string;
}