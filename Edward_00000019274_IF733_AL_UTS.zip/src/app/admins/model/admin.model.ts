export interface Admin{
    id: string;
    imageUrl: string;
    nama: string;
    merek: string;
    model: string;
    harga: string;
    stock: string;
    type: string;
  }
  