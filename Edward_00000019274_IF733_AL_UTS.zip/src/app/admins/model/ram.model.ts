import { Admin } from './admin.model';
export interface RAM extends Admin{
    speed: string;
    size: string;
}